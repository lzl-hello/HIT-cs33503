#include "lru_replacer.h"

LRUReplacer::LRUReplacer(size_t num_pages) { 
    //其中 max_size_ 代表LRU替换器（Replacer）的最大容量（页面数目）
    max_size_ = num_pages;
    }

LRUReplacer::~LRUReplacer() = default;

/**
 * @brief 使用LRU策略删除一个victim frame，这个函数能得到frame_id
 * @param[out] frame_id id of frame that was removed, nullptr if no victim was found
 * @return true if a victim frame was found, false otherwise
 */
bool LRUReplacer::Victim(frame_id_t *frame_id) {

    // 它能够避免死锁发生，其构造函数能够自动进行上锁操作，析构函数会对互斥量进行解锁操作，保证线程安全。
    std::scoped_lock lock{latch_};

    //检查list是否为空
    if(LRUlist_.empty()){
        return false;//表示没有可淘汰的页面
    }
    
    //找到list末尾的frame，是最近最少使用的页面
    *frame_id = LRUlist_.back();
    
    //淘汰该页面
    LRUlist_.pop_back();

    return true;
}

/**
 * @brief 固定一个frame, 表明它不应该成为victim（即在replacer中移除该frame_id）
 * @param frame_id the id of the frame to pin
 */
void LRUReplacer::Pin(frame_id_t frame_id) {
    //避免死锁
    std::scoped_lock lock{latch_};

    //遍历list
    for(auto it=LRUlist_.begin();it!=LRUlist_.end();it++)
    {
        //找到对应的frame
        if(*it==frame_id)
        {
            /*
                如果找到了就从 LRUlist_ 中移除该 frame_id。这表示该页面被固定，不再参与替换策略。
                如果未找到指定的 frame_id，则函数不执行任何操作。
            */
            LRUlist_.erase(it);
            return ;
        }
    }

}

/**
 * 取消固定一个frame, 表明它可以成为victim（即将该frame_id添加到replacer）
 * @param frame_id the id of the frame to unpin
 */
void LRUReplacer::Unpin(frame_id_t frame_id) {

    //避免死锁
    std::scoped_lock lock{latch_};
    //遍历list
    for(auto it=LRUlist_.begin();it!=LRUlist_.end();it++)
    {
        //在替换池中找到，无需任何操作
        if(*it==frame_id)
        {
            return ;
        }
    }
    // 如果未找到指定的 frame_id，将其添加到 LRUlist_ 的开头，表示取消固定并重新参与替换策略
    LRUlist_.push_front(frame_id);
}

/** @return replacer中能够victim的数量 */
size_t LRUReplacer::Size() {
    // Todo:
    // 改写return size
    return LRUlist_.size();
}