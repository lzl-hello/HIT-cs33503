#include "buffer_pool_manager.h"

/**
 * @brief 从free_list或replacer中得到可淘汰帧页的 *frame_id
 * @param frame_id 帧页id指针,返回成功找到的可替换帧id
 * @return true: 可替换帧查找成功 , false: 可替换帧查找失败
 */
bool BufferPoolManager::FindVictimPage(frame_id_t *frame_id) {
    // 
    //  1 使用BufferPoolManager::free_list_判断缓冲池是否已满需要淘汰页面
    //  1.1 未满获得frame
    //  1.2 已满使用lru_replacer中的方法选择淘汰页面
    return true;
}

/**
 * @brief 更新页面数据, 为脏页则需写入磁盘，更新page元数据(data, is_dirty, page_id)和page table
 *
 * @param page 写回页指针
 * @param new_page_id 写回页新page_id
 * @param new_frame_id 写回页新帧frame_id
 */
void BufferPoolManager::UpdatePage(Page *page, PageId new_page_id, frame_id_t new_frame_id) {
    
    //  1 如果是脏页，写回磁盘，并且把dirty置为false
    //  2 更新page table
    //  3 重置page的data，更新page id
}

/**
 * Fetch the requested page from the buffer pool.
 * 如果页表中存在page_id（说明该page在缓冲池中），并且pin_count++。
 * 如果页表不存在page_id（说明该page在磁盘中），则找缓冲池victim page，将其替换为磁盘中读取的page，pin_count置1。
 * @param page_id id of page to be fetched
 * @return the requested page
 */
Page *BufferPoolManager::FetchPage(PageId page_id) {

    //检查请求的页号是有效页号
    assert(page_id.page_no!=INVALID_PAGE_ID);
    //上锁，避免死锁
    std::scoped_lock lock{latch_};

    frame_id_t *frame_id = new frame_id_t;

    // true表示被pin住了
    bool flag = true; 

    //遍历缓冲池中的页面，检查是否有空闲页面
    for (int i = 0; i < int(pool_size_ - free_list_.size()); i++) {
        if (pages_[i].pin_count_ <= 0) {
            flag = false;
            break;
        }
        if(pages_[i].id_==page_id)
        {
            flag=false;
            break;
        }
    }
    if (flag && free_list_.empty()) {
        //如果全部pin住了那缓冲池就无空闲页面
        return nullptr;  
    }

    // 如果找到页面
    if (page_table_.find(page_id) != page_table_.end()) {

        // 页面已存在于缓冲池中（page_table_），需要将其 pin 住
        // replacer_->Pin(page_table_[page_id]); 表示将该页面加入替换器（replacer）的固定列表，防止被替换出去
        replacer_->Pin(page_table_[page_id]);
        //返回页面指针
        return pages_ + page_table_[page_id];
    } else {
        // 如果不存在应该从替换器中获取
        if (free_list_.empty()) {
            // 如果空闲列表（free_list_）为空，说明没有可以直接使用的空闲页面
            // 从替换器中选择一个页面来替换，替换后的页面信息会存储在 frame_id 中
            replacer_->Victim(frame_id);
        } else {
            // 如果 P 不存在但空闲列表有额外的空间
            // 从空闲列表中选择一个页面，将其 frame_id 存储在 *frame_id 中
            *frame_id = free_list_.front();
            // 从空闲列表中移除该页面，因为它即将被使用
            free_list_.pop_front();
        }
    }

    // 如果页面是脏页，表示内容被修改过
    if (pages_[*frame_id].is_dirty_) {
        //先写回磁盘
        disk_manager_->write_page(pages_[*frame_id].GetPageId().fd, pages_[*frame_id].GetPageId().page_no,
                                  pages_[*frame_id].GetData(), PAGE_SIZE);
        //标记不是脏页
        pages_[*frame_id].is_dirty_ = false;
    }
    //删除原先页面，增加新页面
    page_table_.erase(pages_[*frame_id].id_);
    page_table_.insert({page_id, *frame_id});

    pages_[*frame_id].is_dirty_ = false;//新加载，还不是脏页
    pages_[*frame_id].id_ = page_id;//设置页面id
    pages_[*frame_id].pin_count_++;//pin+1；因为此时被锁定

    // 从磁盘读取新请求的页面内容
    disk_manager_->read_page(page_id.fd, page_id.page_no, pages_[*frame_id].data_, PAGE_SIZE);
    // 返回指向新请求的页面的指针
    auto retp = (pages_ + (*frame_id));
    delete frame_id;
    return retp;
}

/**
 * Unpin the target page from the buffer pool. 取消固定pin_count>0的在缓冲池中的page
 * @param page_id id of page to be unpinned
 * @param is_dirty true if the page should be marked as dirty, false otherwise
 * @return false if the page pin count is <= 0 before this call, true otherwise
 */
bool BufferPoolManager::UnpinPage(PageId page_id, bool is_dirty) {

    //上锁，避免死锁
    std::scoped_lock lock{latch_};
    frame_id_t *frame_id = new frame_id_t;
    // 找到页面
    if (page_table_.find(page_id) != page_table_.end()) {
        *frame_id = page_table_[page_id];
        //pin-1；表示解除一次固定
        if (pages_[*frame_id].pin_count_ > 0) {
            pages_[*frame_id].pin_count_--;
        }
        //如果pin为0了，表示不再被锁定
        if (pages_[*frame_id].pin_count_ == 0) {
            
            // 将页面加入替换器的未固定列表
            replacer_->Unpin(*frame_id);
            
        }
        // 如果页面需要置脏，将其加入替换器的未固定列表
        if (is_dirty == true) {
                pages_[*frame_id].is_dirty_ = true;
            }
        return true;
    } else
        return false;
}

/**
 * Flushes the target page to disk. 将page写入磁盘；不考虑pin_count
 * @param page_id id of page to be flushed, cannot be INVALID_PAGE_ID
 * @return false if the page could not be found in the page table, true otherwise
 */
bool BufferPoolManager::FlushPage(PageId page_id) {

    //上锁
    std::scoped_lock lock{latch_};
    //遍历，找页面
    for (size_t i = 0; i < pool_size_; i++) {
        Page *page = &pages_[i];
        //如果找到页面并且该页面的页号匹配指定的页号
        if (page->GetPageId().page_no != INVALID_PAGE_ID && page->GetPageId() == page_id) {
            //写回磁盘
            disk_manager_->write_page(page->GetPageId().fd, page->GetPageId().page_no, page->GetData(), PAGE_SIZE);
            //变为不是脏页
            page->is_dirty_ = false;
            return true;
        }
    }
    return false;
}

/**
 * Creates a new page in the buffer pool. 相当于从磁盘中移动一个新建的空page到缓冲池某个位置
 * @param[out] page_id id of created page
 * @return nullptr if no new pages could be created, otherwise pointer to new page
 */
Page *BufferPoolManager::NewPage(PageId *page_id) {

    //上锁
    std::scoped_lock lock{latch_};
    bool flag = true;  // flag表示现有的都被pin住了
    bool from_free = true;
    //遍历看有没有空闲页面
    for (int i = 0; i < int(pool_size_ - free_list_.size()); i++) {
        if (pages_[i].pin_count_ <= 0) {
            flag = false;
            break;
        }
    }
    //如果缓冲池中的所有页面都被固定，且空闲列表为空，返回 nullptr
    if (flag && free_list_.empty()) return nullptr;

    //选择一个页面作为牺牲者，从空闲列表或替换器中选择，优先从空闲列表选择
    frame_id_t *frame_id = new frame_id_t;
    if (free_list_.empty()) {
        //空闲列表为空，从替换器中选择
        replacer_->Victim(frame_id);
        //如果选择的是脏页，先写回磁盘
        if (pages_[*frame_id].is_dirty_) {
            disk_manager_->write_page(pages_[*frame_id].GetPageId().fd, pages_[*frame_id].GetPageId().page_no,
                                    pages_[*frame_id].GetData(), PAGE_SIZE);
            pages_[*frame_id].is_dirty_ = false;
        }
        from_free = false;
    } else {
        //从空闲列表中选择
        *frame_id = free_list_.front();
        free_list_.pop_front();
    }

    page_id->page_no = disk_manager_->AllocatePage(page_id->fd);

    //更新页面的元数据，清零内存，将 P 添加到页表，固定次数设为 1
    if (!from_free) page_table_.erase(pages_[*frame_id].id_);
    page_table_.insert({*page_id, *frame_id});
    pages_[*frame_id].ResetMemory();
    pages_[*frame_id].id_ = *page_id;
    replacer_->Pin(*frame_id);
    pages_[*frame_id].pin_count_ = 1;
    //返回指针
    auto retp = (pages_ + (*frame_id));
    delete frame_id;
    return retp;
}

/**
 * @brief Deletes a page from the buffer pool.
 * @param page_id id of page to be deleted
 * @return false if the page exists but could not be deleted, true if the page didn't exist or deletion succeeded
 */
bool BufferPoolManager::DeletePage(PageId page_id) {

    //上锁
    std::scoped_lock lock{latch_};
    frame_id_t *frame_id = new frame_id_t;
    // 如果页面在页表中存在
    if (page_table_.find(page_id) != page_table_.end()) {
        *frame_id = page_table_[page_id];
        if (pages_[*frame_id].pin_count_ > 0) {
            //说明有其他操作在使用该页面
            return false;
        }
        //删除页面
        page_table_.erase(page_id);
        pages_[*frame_id].ResetMemory();
        pages_[*frame_id].pin_count_ = 0;
        pages_[*frame_id].is_dirty_ = false;
        free_list_.push_front(*frame_id);//添加到空闲列表
        disk_manager_->DeallocatePage(page_id.page_no);
    }
    delete frame_id;
    return true;
}

/**
 * @brief Flushes all the pages in the buffer pool to disk.
 *
 * @param fd 指定的diskfile open句柄
 */
void BufferPoolManager::FlushAllPages(int fd) {
    // example for disk write
    std::scoped_lock lock{latch_};
    for (size_t i = 0; i < pool_size_; i++) {
        Page *page = &pages_[i];
        if (page->GetPageId().fd == fd && page->GetPageId().page_no != INVALID_PAGE_ID) {
            disk_manager_->write_page(page->GetPageId().fd, page->GetPageId().page_no, page->GetData(), PAGE_SIZE);
            page->is_dirty_ = false;
        }
    }
}