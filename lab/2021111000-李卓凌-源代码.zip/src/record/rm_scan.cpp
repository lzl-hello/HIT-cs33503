#include "rm_scan.h"

#include "rm_file_handle.h"

/**
 * @brief 初始化file_handle和rid
 *
 * @param file_handle
 */
RmScan::RmScan(const RmFileHandle *file_handle) : file_handle_(file_handle) {
    /*
    初始化 rid_： 使用成员初始化列表，将 rid_ 成员初始化为 Rid{RM_FIRST_RECORD_PAGE, -1}
    这个 Rid 对象用于表示扫描的起始位置，即第一个存放记录的页面（RM_FIRST_RECORD_PAGE）和槽位号（-1，表示尚未指定槽位）。
    */
    rid_ = Rid{RM_FIRST_RECORD_PAGE, -1};
    //准备扫描下一个记录
    next();
}

/**
 * @brief 找到文件中下一个存放了记录的位置
 */
void RmScan::next() {
    // 找到文件中下一个存放了记录的非空闲位置，用 rid_ 来指向这个位置
    while (rid_.page_no < file_handle_->file_hdr_.num_pages) {
        // 获取页面句柄
        RmPageHandle ph = file_handle_->fetch_page_handle(rid_.page_no);

        // 寻找下一个被设置的位（即非空闲的槽位）
        rid_.slot_no = Bitmap::next_bit(true, ph.bitmap, file_handle_->file_hdr_.num_records_per_page, rid_.slot_no);

        // 如果找到了非空闲槽位，返回
        if (rid_.slot_no < file_handle_->file_hdr_.num_records_per_page) {
            return;
        }

        // 如果当前页没有非空闲槽位，重置槽位号并切换到下一页
        rid_.slot_no = -1;
        rid_.page_no++;
    }

    // 文件中没有下一个记录
    rid_.page_no = RM_NO_PAGE;
}

/**
 * @brief ​ 判断是否到达文件末尾
 */
bool RmScan::is_end() const {
    // Todo: 修改返回值
     return rid_.page_no == RM_NO_PAGE;
}

/**
 * @brief RmScan内部存放的rid
 */
Rid RmScan::rid() const {
    // Todo: 修改返回值
     return rid_;
}
/*
一些概念的理解加深：

页面（Page）： 数据库将数据组织成若干页面，每个页面有固定的大小。页面是存储记录的地方。

槽位（Slot）： 页面中的每个小格子被称为槽位，用于存储一条记录。一个页面可以有多个槽位，每个槽位对应一条记录。

页面句柄（Page Handle）： 页面句柄是一个对象，用于操作页面。比如，可以通过页面句柄获取页面中的数据，或者修改页面的内容。

记录（Record）： 记录是实际存储数据的单位。一条记录对应数据库中的一条数据。

Rid： Rid 是记录的标识符，用于唯一标识数据库中的一条记录。它包含了页面号和槽位号，指示了记录在哪个页面的哪个槽位上。

RmScan 类用于扫描数据库中的记录。next 函数的作用是查找下一个非空闲的槽位，即存放记录的位置，并更新 rid_ 指向这个位置。
*/