#include "rm_file_handle.h"

/**
 * @brief 由Rid得到指向RmRecord的指针
 *
 * @param rid 指定记录所在的位置
 * @return std::unique_ptr<RmRecord>
 */
std::unique_ptr<RmRecord> RmFileHandle::get_record(const Rid &rid, Context *context) const {

    //获取指定记录所在的 page handle
    auto record = std::make_unique<RmRecord>(file_hdr_.record_size);
	RmPageHandle ph = fetch_page_handle(rid.page_no);

    //检查指定槽位是否有效（位图标记）
	if (!Bitmap::test(ph.bitmap, rid.slot_no)) {
        throw RecordNotFoundError(rid.page_no, rid.slot_no);
    }
    //获取指定槽位的数据并复制到 RmRecord 中
	char *slot = ph.get_slot(rid.slot_no);
	memcpy(record->data, slot, file_hdr_.record_size);
    //设置 RmRecord 的 size 属性
    record->size = file_hdr_.record_size;
    //返回包含记录数据的 std::unique_ptr<RmRecord>
    return record;
}

/**
 * @brief 在该记录文件（RmFileHandle）中插入一条记录
 *
 * @param buf 要插入的数据的地址
 * @return Rid 插入记录的位置
 */
Rid RmFileHandle::insert_record(char *buf, Context *context) {

    // 1. 创建一个新的页面句柄
    RmPageHandle ph = create_page_handle();

    // 2. 在页面位图中找到第一个未使用的槽位
    int slot_no = Bitmap::first_bit(false, ph.bitmap, file_hdr_.num_records_per_page);

    // 3. 标记位图中的槽位为已使用
    Bitmap::set(ph.bitmap, slot_no);

    // 4. 更新页面头信息：增加记录数
    ph.page_hdr->num_records++;

    // 5. 如果页面满了，更新文件头信息
    if (ph.page_hdr->num_records == file_hdr_.num_records_per_page) {
        file_hdr_.first_free_page_no = ph.page_hdr->next_free_page_no;
    }

    // 6. 获取指定槽位的数据并复制传入的数据
    char *slot = ph.get_slot(slot_no);
    memcpy(slot, buf, file_hdr_.record_size);

    // 7. 返回新插入记录的 Rid（页面号和槽位号）
    return Rid{ph.page->GetPageId().page_no, slot_no};
}

/**
 * @brief 在该记录文件（RmFileHandle）中删除一条指定位置的记录
 *
 * @param rid 要删除的记录所在的指定位置
 */
void RmFileHandle::delete_record(const Rid &rid, Context *context) {

    // 1. 获取指定记录所在的 page handle
    RmPageHandle ph = fetch_page_handle(rid.page_no);

    // 2. 检查指定槽位是否有效（位图标记）
    if (!Bitmap::test(ph.bitmap, rid.slot_no)) {
        throw RecordNotFoundError(rid.page_no, rid.slot_no);
    }

    // 3. 如果删除记录后页面未满，调用 release_page_handle() 释放页面句柄
    if (ph.page_hdr->num_records == file_hdr_.num_records_per_page) {
        release_page_handle(ph);
    }

    // 4. 重置位图中的槽位为未使用
    Bitmap::reset(ph.bitmap, rid.slot_no);

    // 5. 更新页面头信息：减少记录数
    ph.page_hdr->num_records--;
}

/**
 * @brief 更新指定位置的记录
 *
 * @param rid 指定位置的记录
 * @param buf 新记录的数据的地址
 */
void RmFileHandle::update_record(const Rid &rid, char *buf, Context *context) {

    // 1. 获取指定记录所在的 page handle
    RmPageHandle ph = fetch_page_handle(rid.page_no);
    // 2. 检查指定槽位是否有效（位图标记）
	if (!Bitmap::test(ph.bitmap, rid.slot_no)) {
        throw RecordNotFoundError(rid.page_no, rid.slot_no);
    }
	// 3. 获取指定槽位的数据并更新
    char *slot = ph.get_slot(rid.slot_no);
    memcpy(slot, buf, file_hdr_.record_size);
}

/** -- 以下为辅助函数 -- */
/**
 * @brief 获取指定页面编号的page handle
 *
 * @param page_no 要获取的页面编号
 * @return RmPageHandle 返回给上层的page_handle
 * @note pin the page, remember to unpin it outside!
 */
RmPageHandle RmFileHandle::fetch_page_handle(int page_no) const {

    // 检查页面号是否有效，如果无效则抛出 PageNotExistError 异常
    if(page_no >= file_hdr_.num_pages)
		throw PageNotExistError("??" ,page_no);
    // 构造 PageId 对象，表示文件和页面号
	PageId page_id;
	page_id.fd = fd_;
	page_id.page_no = page_no;
	// 从缓冲池中获取指定页面
	Page *page = nullptr;
	page = buffer_pool_manager_->FetchPage(page_id);
    // 返回 RmPageHandle 对象，包装文件头信息和获取的页面
    return RmPageHandle(&file_hdr_, page);
}

/**
 * @brief 创建一个新的page handle
 *
 * @return RmPageHandle
 */
RmPageHandle RmFileHandle::create_new_page_handle() {

    // 1. 使用缓冲池来创建一个新page
    PageId *page_id = new PageId;
	page_id->fd = fd_;

	Page *page = nullptr;
	page = buffer_pool_manager_->NewPage(page_id);
    // 2. 更新page handle中的相关信息
	RmPageHandle ph = RmPageHandle(&file_hdr_, page); 
    // 初始化新页面的相关信息
	ph.page_hdr->num_records = 0;
	ph.page_hdr->next_free_page_no = RM_NO_PAGE;
	Bitmap::init(ph.bitmap, file_hdr_.bitmap_size);
    // 3. 更新文件头信息
	file_hdr_.num_pages ++;
	file_hdr_.first_free_page_no = page->GetPageId().page_no;

    return ph;
}

/**
 * @brief 创建或获取一个空闲的page handle
 *
 * @return RmPageHandle 返回生成的空闲page handle
 * @note pin the page, remember to unpin it outside!
 */
RmPageHandle RmFileHandle::create_page_handle() {
    // Todo:
    // 1. 判断file_hdr_中是否还有空闲页
    //     1.1 没有空闲页：使用缓冲池来创建一个新page；可直接调用create_new_page_handle()
    //     1.2 有空闲页：直接获取第一个空闲页
    // 2. 生成page handle并返回给上层

    if(file_hdr_.first_free_page_no != RM_NO_PAGE){
        //todo写的很清楚，若有空闲页
		return fetch_page_handle(file_hdr_.first_free_page_no);
	}
    //若无空闲页
	else return create_new_page_handle();
}

/**
 * @brief 当page handle中的page从已满变成未满的时候调用
 *
 * @param page_handle
 * @note only used in delete_record()
 */
void RmFileHandle::release_page_handle(RmPageHandle &page_handle) {

    /*
    更新 page_handle.page_hdr->next_free_page_no： 
    将页面句柄中的 next_free_page_no 更新为文件头中的第一个空闲页面号，表示该页面的下一个空闲页面是文件中当前的第一个空闲页面。
    */
    page_handle.page_hdr->next_free_page_no = file_hdr_.first_free_page_no;
    /*
    更新 file_hdr_.first_free_page_no： 
    将文件头中的 first_free_page_no 更新为当前页面的页面号，表示文件中的第一个空闲页面是当前页面
    */
	file_hdr_.first_free_page_no = page_handle.page->GetPageId().page_no;
}

/**
 * @brief 用于事务的rollback操作
 *
 * @param rid record的插入位置
 * @param buf record的内容
 */
void RmFileHandle::insert_record(const Rid &rid, char *buf) {
    if (rid.page_no < file_hdr_.num_pages) {
        create_new_page_handle();
    }
    RmPageHandle pageHandle = fetch_page_handle(rid.page_no);
    Bitmap::set(pageHandle.bitmap, rid.slot_no);
    pageHandle.page_hdr->num_records++;
    if (pageHandle.page_hdr->num_records == file_hdr_.num_records_per_page) {
        file_hdr_.first_free_page_no = pageHandle.page_hdr->next_free_page_no;
    }

    char *slot = pageHandle.get_slot(rid.slot_no);
    memcpy(slot, buf, file_hdr_.record_size);

    buffer_pool_manager_->UnpinPage(pageHandle.page->GetPageId(), true);
}
